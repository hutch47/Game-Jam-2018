﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Health : MonoBehaviour {
    public float max;
    public float value;

	// Use this for initialization
	void Start () {
        value = 25f;
        max = 25f;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}

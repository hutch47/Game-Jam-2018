<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Tileset1" tilewidth="64" tileheight="64" tilecount="64" columns="8">
 <image source="tileset1.png" width="512" height="512"/>
 <tile id="0">
  <objectgroup draworder="index">
   <object id="2" x="0" y="0" width="64" height="64"/>
  </objectgroup>
 </tile>
 <tile id="1">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="64" height="64"/>
  </objectgroup>
 </tile>
 <tile id="2">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="64" height="64"/>
  </objectgroup>
 </tile>
</tileset>
